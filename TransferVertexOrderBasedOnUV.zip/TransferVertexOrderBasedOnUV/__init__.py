bl_info = {
    "name": "Transfer Vertex Order Based on UV",
    "author": "Liyou",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "3D View > Tool Shelf > Transfer Vertex Order",
    "description": "Transfers vertex order from a source object to a target object based on UV mapping.",
    "warning": "",
    "wiki_url": "https://www.youtube.com/@vectorwang9632",
    "category": "Object",
}

import bpy
import bmesh

def transfer_vertex_order_based_on_uv(source_obj, target_obj):
    source_mesh = source_obj.data
    target_mesh = target_obj.data

    # Check if UV layers exist
    if len(source_mesh.uv_layers) == 0 or len(target_mesh.uv_layers) == 0:
        return "Source or Target has no UV layer!"

    # Get UV layers
    source_uv_layer = source_mesh.uv_layers.active.data
    target_uv_layer = target_mesh.uv_layers.active.data

    # Map source UV to vertex indices
    source_uv_to_index = {}
    for loop in source_mesh.loops:
        uv = source_uv_layer[loop.index].uv
        source_uv_to_index[(uv.x, uv.y)] = loop.vertex_index

    # Create new vertex order for target
    new_vertex_order = [-1] * len(target_mesh.vertices)
    for loop in target_mesh.loops:
        uv = target_uv_layer[loop.index].uv
        uv_key = (uv.x, uv.y)
        if uv_key in source_uv_to_index:
            new_vertex_order[loop.vertex_index] = source_uv_to_index[uv_key]

    # Check for unmapped vertices
    if -1 in new_vertex_order:
        return "Some vertices are not mapped correctly. Check if the UVs match perfectly!"

    # Apply new vertex order to target
    bm = bmesh.new()
    bm.from_mesh(target_mesh)
    bm.verts.ensure_lookup_table()
    bm.verts.sort(key=lambda v: new_vertex_order[v.index])
    bm.to_mesh(target_mesh)
    bm.free()

    return "Vertex order successfully transferred from '{}' to '{}'!".format(source_obj.name, target_obj.name)


# UI Panel for the Add-on
class OBJECT_PT_TransferVertexOrder(bpy.types.Panel):
    bl_label = "Transfer Vertex Order Based On UV"
    bl_idname = "OBJECT_PT_transfer_vertex_order"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Transfer Vertex Order"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Transfer Vertex Order Based on UV")
        layout.prop(context.scene, "source_object", text="Source Object")
        layout.prop(context.scene, "target_object", text="Target Object")
        layout.operator("object.transfer_vertex_order", text="Transfer")


class OBJECT_OT_TransferVertexOrderOperator(bpy.types.Operator):
    bl_idname = "object.transfer_vertex_order"
    bl_label = "Transfer Vertex Order"
    bl_description = "Transfer vertex order from a source object to a target object based on UV mapping"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        source_obj = context.scene.source_object
        target_obj = context.scene.target_object

        if not source_obj or not target_obj:
            self.report({'ERROR'}, "Source or Target object is not set!")
            return {'CANCELLED'}

        result = transfer_vertex_order_based_on_uv(source_obj, target_obj)
        if "successfully" in result:
            self.report({'INFO'}, result)
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, result)
            return {'CANCELLED'}


def register():
    bpy.utils.register_class(OBJECT_PT_TransferVertexOrder)
    bpy.utils.register_class(OBJECT_OT_TransferVertexOrderOperator)
    bpy.types.Scene.source_object = bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Source Object",
        description="The object to copy vertex order from"
    )
    bpy.types.Scene.target_object = bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Target Object",
        description="The object to copy vertex order to"
    )


def unregister():
    bpy.utils.unregister_class(OBJECT_PT_TransferVertexOrder)
    bpy.utils.unregister_class(OBJECT_OT_TransferVertexOrderOperator)
    del bpy.types.Scene.source_object
    del bpy.types.Scene.target_object


if __name__ == "__main__":
    register()

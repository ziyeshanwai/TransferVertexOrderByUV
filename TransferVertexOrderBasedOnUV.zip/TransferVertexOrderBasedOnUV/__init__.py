bl_info = {
    "name": "Transfer Vertex Order Based on UV",
    "author": "Liyou",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "3D View > Tool Shelf > Transfer Vertex Order",
    "description": "Transfers vertex order from a source object to a target object based on UV mapping.",
    "warning": "",
    "wiki_url": "https://www.youtube.com/@vectorwang9632",
    "category": "Object",
}

import bpy
import bmesh
from scipy.spatial import KDTree
import numpy as np


def get_vertex_uvs(obj):
    """Get the first associated UV coordinates for each vertex"""
    mesh = obj.data
    if not mesh.uv_layers:
        raise ValueError("The object does not have UV layers")
    
    uv_layer = mesh.uv_layers.active.data
    vertex_uvs = {}
    
    # Iterate over all loops and record the first UV coordinate for each vertex
    for loop in mesh.loops:
        v_idx = loop.vertex_index
        if v_idx not in vertex_uvs:
            vertex_uvs[v_idx] = np.array([uv_layer[loop.index].uv[0], uv_layer[loop.index].uv[1]])
    
    # Convert to a list sorted by vertex index
    return [vertex_uvs[i] for i in range(len(mesh.vertices))]

def transfer_vertex_order(source_obj, target_obj, tolerance=1e-3):
    """
    Transfer the vertex order from the source object to the target object based on UV coordinates
    
    Parameters:
    source_obj: Source object
    target_obj: Target object
    tolerance: Tolerance value for UV matching
    """
    try:
        # Verify that UV layers exist
        if not source_obj.data.uv_layers or not target_obj.data.uv_layers:
            raise ValueError("Both the source and target objects must have UV layers")

        # Get UV coordinates data
        source_uvs = np.array(get_vertex_uvs(source_obj))
        target_uvs = np.array(get_vertex_uvs(target_obj))
        # Check vertex count consistency
        if len(source_uvs) != len(target_uvs):
            raise ValueError("The source and target objects must have the same number of vertices")

        # Construct a KDTree for fast querying
        kd_tree = KDTree(target_uvs)

        # Find the nearest UV points and establish the vertex mapping
        distances, vertex_map = kd_tree.query(source_uvs, k=1)

        # Check if all points are within the tolerance range
        if np.any(distances > tolerance):
            problematic_uvs = source_uvs[distances > tolerance]
            raise ValueError(f"There are {len(problematic_uvs)} UV coordinates that couldn't find a matching point")

        # Verify mapping uniqueness
        # if len(np.unique(vertex_map)) != len(source_uvs):
        #     raise ValueError("There are multiple source vertices mapped to the same target vertex")

        # Create a reverse mapping table
        reverse_map = {old_idx: new_idx for new_idx, old_idx in enumerate(vertex_map)}

        # Use BMesh to handle the target mesh
        bm = bmesh.new()
        bm1 = bmesh.new()
        bm.from_mesh(target_obj.data)
        bm1.from_mesh(source_obj.data)
        bm.verts.ensure_lookup_table()
        bm1.verts.ensure_lookup_table()

        # Create a new BMesh and reorder vertices according to the new order
        new_bm = bmesh.new()
        new_vertices = [new_bm.verts.new(bm.verts[k].co) for i,k in enumerate(vertex_map)]
        # src_vertices = [new_bm.verts.new(bm1.verts[i].co) for i in range(0, len(vertex_map))]
        new_bm.verts.ensure_lookup_table()
        uv_layer_source = bm1.loops.layers.uv.active
        uv_layer_new = new_bm.loops.layers.uv.new("UVMap")

        # Rebuild topology
        for face in bm1.faces:
            try:
                # Convert vertex indices to the new order
                new_verts = [new_vertices[v.index] for v in face.verts]
                new_face = new_bm.faces.new(new_verts)
                for loop_new, loop_source in zip(new_face.loops, face.loops):
                    # The correct way is to access UV data through the UV layer
                    loop_new[uv_layer_new].uv = loop_source[uv_layer_source].uv.copy()

            except ValueError as e:
                # print(f"Warning: Skipping invalid face - {str(e)}")
                continue
        # new_mesh  = bpy.data.meshes.new("NewMesh")
        # new_bm.to_mesh(new_mesh)
        new_bm.to_mesh(target_obj.data)
        # new_object = bpy.data.objects.new("NewObject", new_mesh)
        # bpy.context.scene.collection.objects.link(new_object)
        bm1.free()
        new_bm.free()
        bm.free()
        return "Vertex order transfer completed successfully!"

    except Exception as e:
        if 'new_bm' in locals():
            new_bm.free()
        if 'bm' in locals():
            bm.free()

        if 'bm1' in locals():
            bm1.free()
        return str(e)



# UI Panel for the Add-on
class OBJECT_PT_TransferVertexOrder(bpy.types.Panel):
    bl_label = "Transfer Vertex Order Based On UV"
    bl_idname = "OBJECT_PT_transfer_vertex_order"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Transfer Vertex Order"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Transfer Vertex Order Based on UV")
        layout.prop(context.scene, "source_object", text="Source Object")
        layout.prop(context.scene, "target_object", text="Target Object")
        layout.prop(context.scene, "tolerance", text="tolerance") 
        layout.operator("object.transfer_vertex_order", text="Transfer")
       


class OBJECT_OT_TransferVertexOrderOperator(bpy.types.Operator):
    bl_idname = "object.transfer_vertex_order"
    bl_label = "Transfer Vertex Order"
    bl_description = "Transfer vertex order from a source object to a target object based on UV mapping"
    bl_options = {'REGISTER', 'UNDO'}


    def execute(self, context):
        source_obj = context.scene.source_object
        target_obj = context.scene.target_object
        tolerance = context.scene.tolerance
        if not source_obj or not target_obj:
            self.report({'ERROR'}, "Source or Target object is not set!")
            return {'CANCELLED'}

        # result = transfer_vertex_order_based_on_uv2(source_obj, target_obj)
        result = transfer_vertex_order(source_obj, target_obj, tolerance=tolerance)
        if "successfully" in result:
            self.report({'INFO'}, result)
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, result)
            return {'CANCELLED'}


def register():
    bpy.utils.register_class(OBJECT_PT_TransferVertexOrder)
    bpy.utils.register_class(OBJECT_OT_TransferVertexOrderOperator)
    bpy.types.Scene.source_object = bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Source Object",
        description="The object to copy vertex order from"
    )
    bpy.types.Scene.target_object = bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Target Object",
        description="The object to copy vertex order to"
    )
    bpy.types.Scene.tolerance = bpy.props.FloatProperty(
        name="tolerance",
        description="source and target uv tolerance",
        default=0.001,
        min=0.0,
        max=0.1,
        step=0.001,
        precision=7
    )


def unregister():
    bpy.utils.unregister_class(OBJECT_PT_TransferVertexOrder)
    bpy.utils.unregister_class(OBJECT_OT_TransferVertexOrderOperator)
    del bpy.types.Scene.source_object
    del bpy.types.Scene.target_object
    del bpy.types.Scene.tolerance



if __name__ == "__main__":
    register()
